#!/bin/sh

gcc -Wall -o bgp_md5crack main.c md5.c -lpcap
strip bgp_md5crack
